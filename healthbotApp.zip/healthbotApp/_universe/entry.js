import Expo from 'expo';
import App from '../App.js';

Expo.registerRootComponent(App);
