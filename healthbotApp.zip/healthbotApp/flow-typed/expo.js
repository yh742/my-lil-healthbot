/**
 * @flow
 */
 
 declare module 'expo' {
   declare module.exports: any;
 }