/**
 * @flow
 */
 
 declare module 'react-navigation' {
   declare module.exports: any;
 }